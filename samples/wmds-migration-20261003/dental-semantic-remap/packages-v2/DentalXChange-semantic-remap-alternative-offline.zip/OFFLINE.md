# Offline maintainer package

Includes private source/context/evidence. Extract into a new directory. Runtime is pinned to its original OS/architecture and executable hash; fonts and calibration are in the bundled library.

From the extracted package:

```sh
chmod +x runtime/pptxdesign
WMDS_BRANDING_ROOT="$PWD/runtime/branding" runtime/pptxdesign project check --project . --bundle runtime/library/wm-design-system/pinned
```

Use the engine in toolchain.lock.json explicitly if it differs from the project command default. This package does not install fonts into PowerPoint or contain native PowerPoint/PDF conversion.
