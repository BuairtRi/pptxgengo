# DentalXChange — qualified semantic alternative57

Current maintained source: deck.yaml. All57 original identities,15hidden flags,7native sections, source businesscopy and originalnotes remain. Native qualification carries allslide/media/notes/chart/workbook payloads byte-exact from the accepted prior native deck; only seven source-seeded section UUID values changed. Original six chart numeric zeros remain unchanged.

This source cleanup removes7unusedempty zones and saves57exactoriginalpagebriefs as context/*.md. No visualcontent/runtimepin changes. The historical native inspection PDF belongs to the actual reviewed predecessor, not a newly exported rendering of this package. See qualification/native-final-closed-part-carry.json.

Minimal source package: current source/state/build, requiredassets/ancestors/context and qualificationreceipts. No oldbuilds or authoringhelpers. Offline package additionally includes exactfrozenv4compiler and bundled library/fonts/calibration; its pinned upstream source tools are runtime dependencies.
