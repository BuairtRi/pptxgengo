# Patterson Eaglesoft — four alternative layouts

All four alternative pages were individually accepted in native PowerPoint. These present the same original content with a different visual argument; they do not replace the preferred 39-page deck.

| Alternative | Source | Comparison |
|---:|---:|---|
|1|3|Heard/outcomes in two columns versus central ask|
|2|11|Three route cards with common foundation versus route rows|
|3|22|Task-level schedule grid versus phase/gate Gantt|
|4|29|Results-led case evidence versus quote-led case evidence|

Source: `deck.yaml`. Current accepted PPTX: `builds/build-20261004T032708-7df1fdf2e2efd1c5/deck.pptx`. Native receipt: `qualification/native-final-receipt.json`. Original wording and notes are retained in slide notes. Only the current source/build, required assets/contracts/context and qualification receipts are packaged.

## Offline rebuild

On macOS arm64, from the extracted offline ZIP:

```sh
chmod +x runtime/pptxdesign
WMDS_BRANDING_ROOT="$PWD/runtime/branding" runtime/pptxdesign project check --project . --bundle runtime/library/wm-design-system/pinned
WMDS_BRANDING_ROOT="$PWD/runtime/branding" runtime/pptxdesign project build --project . --bundle runtime/library/wm-design-system/pinned
```

No Go installation or network download is needed. The pinned runtime, fonts and calibration are bundled. Native PowerPoint rendering is separate. Source contains private client material and full draft annotations in notes.
