# Patterson Eaglesoft — qualified semantic remap

Preferred deck: `builds/build-20261004T031126-507cd5336b93a80a/deck.pptx` (39 pages, six original hidden flags, eight meaningful sections).

Maintained authoring source: `deck.yaml`. All original notes and visible wording are retained in notes; visible copy is shaped for the page purpose. `PLAN.md` records the semantic recipe choices. `qualification/native-final-receipt.json` records all 39 pages accepted through individual native PowerPoint review. Inspection and alternatives are separate deliverables.

This package contains the current source, required contract snapshots, source media, context, current build and qualification receipts. Historical builds and authoring helpers are excluded. The pinned runtime and frozen source tools are part of reproducibility.

## Offline rebuild

After extracting the offline ZIP on macOS arm64:

```sh
chmod +x runtime/pptxdesign
WMDS_BRANDING_ROOT="$PWD/runtime/branding" runtime/pptxdesign project check --project . --bundle runtime/library/wm-design-system/pinned
WMDS_BRANDING_ROOT="$PWD/runtime/branding" runtime/pptxdesign project build --project . --bundle runtime/library/wm-design-system/pinned
```

No Go installation or network download is needed. Fonts and calibration are bundled; PowerPoint native rendering requires its own installed fonts and application. Runtime hash and platform are recorded in `toolchain-semantic.lock.json`.

Source contains private client material and full draft annotations in notes. Review reuse with the source owner.
